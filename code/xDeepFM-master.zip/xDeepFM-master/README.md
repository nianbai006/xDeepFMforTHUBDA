# xDeepFM

Source code for our KDD 2018 paper : eXtreme Deep Factorization Machine (xDeepFM) https://arxiv.org/abs/1803.05170 .

As stated previously, we are developing an opensource deep learning based factorization toolkit and all mentioned models will be released in a suitable way and time. Currently we only release the source code of xDeepFM model for reference. Some early works can be found here: https://github.com/Leavingseason/OpenLearning4DeepRecsys.

--
Update 2018-07-26:
Some readers meet some troubles when running the source code. I have just updated the codebase, comment some lines which are not use in xDeepFM model, and also upload a data sample. Now you can run the code simply through 'python main.py'. 
